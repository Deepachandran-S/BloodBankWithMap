from dotenv import load_dotenv

load_dotenv()  # take environment variables from .env.

from flask import Flask, render_template, request, redirect, url_for, flash, session,jsonify
from pymongo import MongoClient
from werkzeug.security import generate_password_hash, check_password_hash
from geopy.geocoders import Nominatim
from werkzeug.security import generate_password_hash
from bson import ObjectId
import datetime  # Import the whole module
from bson import json_util
import json


current_time = datetime.datetime.now() 
print(current_time)


app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with a random secret key

# Connect to MongoDB
from pymongo import MongoClient
from geopy.geocoders import Nominatim

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['blood_bank']
donors_collection = db['donors']

# Set up geolocation
geolocator = Nominatim(user_agent="your_app_name")

# Sample data with geolocation
address = "123 Main St, Anytown, USA"
location = geolocator.geocode(address)
if location:
    donor_data = {
        "name": "John Doe",
        "address": address,
        "lat": location.latitude,
        "lng": location.longitude
    }
    # Insert into MongoDB and confirm
    result = donors_collection.insert_one(donor_data)
    print("Data inserted with ID:", result.inserted_id)
else:
    print("Geolocation failed; address not stored.")

client = MongoClient('mongodb://localhost:27017/')  # Adjust the URI as necessary
db = client['blood_bank']
contact_collection = db['contact_messages']
donors_collection = db['donors']
admins_collection = db['admins']
donation_collection = db['donations'] 
appointments_collection = db['appointments']
geolocator = Nominatim(user_agent="your_app_name")

# Routes
@app.route('/')
def index():
    return render_template('index.html')
from geopy.geocoders import Nominatim
from geopy.exc import GeocoderUnavailable, GeocoderTimedOut
import time

geolocator = Nominatim(user_agent="donation_center_locator", timeout=10)

def get_donation_centers():
    centers = []
    
    for admin in admins_collection.find():  # Replace with your query if needed
        address = admin.get('address')  # Assuming the address is stored in 'address' field
        if address:
            retries = 3  # Number of retries for each address
            location = None
            
            for attempt in range(retries):
                try:
                    location = geolocator.geocode(address)
                    if location:
                        break  # Exit retry loop if successful
                except (GeocoderUnavailable, GeocoderTimedOut):
                    print(f"Geocoding failed for address '{address}' (attempt {attempt + 1}). Retrying...")
                    time.sleep(2)  # Wait before retrying

            if location:
                centers.append({
                    'name': admin.get('name'),  # Assuming the admin has a 'name' field
                    'lat': location.latitude,
                    'lng': location.longitude
                })
            else:
                print(f"Could not geocode address: {address}")

    return centers


@app.route('/donar_registration', methods=['GET', 'POST'])
def donor_registration():
    if request.method == 'POST':
        full_name = request.form.get('full-name')
        email = request.form.get('email')
        password = request.form.get('password')
        phone = request.form.get('phone')
        age = request.form.get('age')
        blood_group = request.form.get('blood-group')
        address = request.form.get('address')
        
        hashed_password = generate_password_hash(password)

        # Geocode the address to get latitude and longitude
        geolocator = Nominatim(user_agent="blood_bank_app")
        location = geolocator.geocode(address)

        if location:
            latitude = location.latitude
            longitude = location.longitude
        else:
            flash('Could not geocode the address. Please check and try again.', 'danger')
            print('Geocoding failed for address:', address)  # Debugging line
            return redirect(url_for('donor_registration'))

        # Insert donor information into MongoDB
        donor_data = {
            'full_name': full_name,
            'email': email,
            'password': hashed_password,
            'phone': phone,
            'age': age,
            'blood_group': blood_group,
            'address': address,
            'latitude': latitude,
            'longitude': longitude
        }

        db.donors.insert_one(donor_data)  # Assuming you have a 'donors' collection
        flash('Registration successful! Thank you for registering as a blood donor.', 'success')
        return redirect(url_for('index'))
    

    return render_template('donar_register.html')

@app.route('/api/donors/id/<donor_id>')
def get_donor_details_by_id(donor_id):
    try:
        # Check if donor_id is a valid ObjectId
        if not ObjectId.is_valid(donor_id):
            print("Invalid ObjectId")
            return jsonify({"error": "Invalid Donor ID"}), 400

        # Find the donor using the ObjectId
        donor = db.donors.find_one({"_id": ObjectId(donor_id)})
        date = db.donations.find_one({"donor_id": ObjectId(donor_id)})
        

        if not donor:
            print("Donor not found")
            return jsonify({"error": "Donor not found"}), 404
        if not date:
            print("Date not found")
            return jsonify({"error": "Donor not found"}), 404
        

        # Prepare the donor details
        donor_details = {
            "id": str(donor["_id"]),
            "name": donor["full_name"],
            "bloodGroup": donor["blood_group"],
            "lastDonation": date.get("donation_date", "N/A"),
            "contact": donor.get("phone", "N/A"),
            "address": donor.get("address", "N/A")
        }
        return jsonify(donor_details)
    except Exception as e:
        print(f"Error: {e}")  # Print error for debugging
        return jsonify({"error": str(e)}), 500

    
@app.route('/donar_details.html')
def donar_details():
    return render_template('donar_details.html')

@app.route('/schedule_appointment', methods=['GET', 'POST'])
def schedule_appointment():
    centers = get_donation_centers()
    if request.method == 'POST':
        # Get form data
        donor_name = request.form['donor_name']
        donor_address = request.form['donor_address']
        location = request.form['location']
        date = request.form['date']
        time = request.form['time']

        # Parse date and time
        appointment_date = datetime.datetime.strptime(f"{date} {time}", "%Y-%m-%d %H:%M")

        # Create appointment document
        appointment = {
            'donor_name': donor_name,
            'donor_address': donor_address,
            'location': location,
            'date': date,
            'status': 'Scheduled'
        }

        # Insert appointment into MongoDB
        appointments_collection.insert_one(appointment)

        # Redirect to donar_landing.html after scheduling
        return redirect(url_for('donar_dashboard'))


    # Render the schedule appointment page on GET request
    return render_template('schedule-appointment.html')

@app.route('/get_donation_centers', methods=['GET'])
def get_donation_centers():
    # Fetch all donation centers from the 'admin' collection
    donation_centers = admins_collection.find({}, {'_id': 0, 'address': 1})
    centers_list = []

    for center in donation_centers:
        centers_list.append({
            "address": center.get("address")
        })
    
    return jsonify(centers_list)

@app.route("/api/donors")
def get_donors():
    donors = db.donors.find()
    donors_list = []
    for donor in donors:
        donors_list.append({
            "id": str(donor["_id"]), 
            "name": donor["full_name"],
            "bloodGroup": donor["blood_group"],
            "address": donor["address"],
            "lat": donor["latitude"],
            "lng": donor["longitude"],
            # "lastDonation": donor.get("last_donation", "N/A")  # Modify as needed
        })
    return jsonify(donors_list)
@app.route('/donar_login', methods=['GET', 'POST'])
def donor_login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        # Retrieve the donor data from the database
        donor = db.donors.find_one({'email': email})

        if donor and check_password_hash(donor['password'], password):
            # Password is correct, create a session
            session['donor_email'] = donor['email']  # Make sure this matches in all routes
            flash('Login successful!', 'success')
            return redirect(url_for('donar_dashboard'))
        else:
            flash('Invalid email or password. Please try again.', 'danger')
            return redirect(url_for('donor_login'))

    return render_template('donar_login.html')

@app.route('/logout')
def logout():
    session.pop('donor_email', None)
    flash('You have been logged out.', 'success')
    return redirect(url_for('index'))

@app.route('/donar_dashboard')
def donar_dashboard():
    if 'donor_email' not in session:
        flash('Please log in to access your dashboard.', 'warning')
        return redirect(url_for('donor_login'))

    # Retrieve donor details from the `donors` collection
    donor = db.donors.find_one({'email': session['donor_email']})
    
    if donor:
        # Calculate total blood units donated from the `donations` collection
        total_blood_units = db.donations.aggregate([
            {'$match': {'donor_id': donor['_id']}},
            {'$group': {'_id': None, 'total_units': {'$sum': '$donation_amount'}}}
        ])
        # Extract the total amount or default to 0 if no donations are found
        total_units_donated = next(total_blood_units, {}).get('total_units', 0)

        # Fetch past donation details
        past_donations = list(db.donations.find({'donor_id': donor['_id']}))

        # Update donor data with total donation amount and history
        donor['blood_units_donated'] = total_units_donated
        donor['donation_history'] = past_donations

        return render_template('donar_landing.html', donor=donor)

    flash('Donor information could not be found.', 'danger')
    return redirect(url_for('donor_login'))


@app.route('/admin_register', methods=['GET', 'POST'])
def admin_register():
    if request.method == 'POST':
        # Get form data
        hospital_name = request.form['hospital_name']
        registration_number = request.form['registration_number']
        password = request.form['password']
        contact_person = request.form['contact_person']
        contact_email = request.form['contact_email']
        contact_phone = request.form['contact_phone']
        address = request.form['address']
        city = request.form['city']
        state = request.form['state']
        hospital_type = request.form['hospital_type']


        # Get latitude and longitude
        try:
            location = geolocator.geocode(address)
            if location:
                latitude = location.latitude
                longitude = location.longitude
            else:
                latitude = None
                longitude = None
        except Exception as e:
            flash(f"Error getting location: {str(e)}", "danger")
            latitude = None
            longitude = None

        # Create a dictionary to store in MongoDB
        admin_data = {
            'hospital_name': hospital_name,
            'registration_number': registration_number,
            'password': password,  # Consider hashing the password for security
            'contact_person': contact_person,
            'contact_email': contact_email,
            'contact_phone': contact_phone,
            'address': address,
            'city': city,
            'state': state,
            'hospital_type': hospital_type,
            'latitude': latitude,
            'longitude': longitude
        }

        # Insert data into the admins collection
        admins_collection.insert_one(admin_data)

        flash('Registration successful! You can now log in.', 'success')
        return redirect(url_for('admin_login'))

    return render_template('admin_register.html')

@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        registration_number = request.form['registration_number']
        password = request.form['password']

        # Check if the admin exists in the database using registration number and password
        admin = admins_collection.find_one({'registration_number': registration_number, 'password': password})
        if admin:
            # Successful login
            return redirect(url_for('admin_dashboard'))
        else:
            flash('Invalid registration number or password', 'danger')

    return render_template('admin_login.html')

@app.route('/admin_dashboard')
def admin_dashboard():
    return render_template('admin_dashboard.html')

@app.route('/contact')
def contact():
    return render_template('contact_us.html')  # Create contact.html as needed
@app.route('/contact', methods=['POST'])
def submit_contact_form():
    # Get data from the form
    name = request.form.get('name')
    email = request.form.get('email')
    message = request.form.get('message')

    # Validate form data (optional)
    if not name or not email or not message:
        flash("All fields are required!")
        return redirect(url_for('contact'))

    # Insert data into MongoDB
    contact_data = {
        "name": name,
        "email": email,
        "message": message
    }
    contact_collection.insert_one(contact_data)

    flash("Your message has been sent successfully!")
    return redirect(url_for('contact'))

@app.route('/about')
def about():
    return render_template('about-us.html')  # Create contact.html as needed

@app.route('/api/donors/id/<donor_id>/donation', methods=['POST'])
def record_donation(donor_id):
    try:
        # Get the donation data from the request
        donation_data = request.get_json()
        donation_amount = donation_data.get('amount')

        if not donation_amount:
            return jsonify({'success': False, 'message': 'Donation amount is required'}), 400

        # Ensure the donation_amount is treated as a float
        donation_amount = float(donation_amount)

        # Retrieve donor details from the donors collection using donor_id
        donor = db.donors.find_one({'_id': ObjectId(donor_id)})
        
        if not donor:
            return jsonify({'success': False, 'message': 'Donor not found'}), 404

        # Check if a donation record already exists for this donor
        existing_record = donation_collection.find_one({'donor_id': donor['_id']})

        if existing_record:
            # Ensure that the existing donation amount is treated as a float for the calculation
            existing_donation_amount = float(existing_record['donation_amount'])

            # Update the existing donation record by incrementing the donation amount
            new_total_donation = existing_donation_amount + donation_amount
            donation_collection.update_one(
                {'donor_id': donor['_id']},
                {
                    '$set': {
                        'donation_amount': new_total_donation,
                        'donation_date': datetime.datetime.now().strftime('%Y-%m-%d'),
                        'donation_location': donor.get('address', 'Unknown')  # Update if location changes
                    }
                }
            )
            message = 'Donation updated successfully'

        else:
            # No record exists, create a new one
            donation_record = {
                'donor_id': donor['_id'],
                'donor_name': donor['full_name'],
                'donor_blood_group': donor['blood_group'],
                'donation_amount': donation_amount,
                'donation_date': datetime.datetime.now().strftime('%Y-%m-%d'),
                'donation_location': donor.get('address', 'Unknown')
            }
            donation_collection.insert_one(donation_record)
            message = 'Donation recorded successfully'

        return jsonify({'success': True, 'message': message})

    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/total_donations', methods=['GET'])
def get_total_donations():
    try:
        # Aggregate the sum of all donation_amount in the donations collection
        total_donated = donation_collection.aggregate([
            {"$group": {"_id": None, "total_donated": {"$sum": "$donation_amount"}}}
        ])
        
        # If there are results, extract the sum
        total_donated = list(total_donated)
        total_units = total_donated[0]['total_donated'] if total_donated else 0
        
        return jsonify({'success': True, 'total_units': total_units})

    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500
    
@app.route('/api/admin_count', methods=['GET'])
def get_admin_count():
    try:
        # Count the number of documents in the admins collection
        admin_count = db["admins"].count_documents({})
        return jsonify(success=True, admin_count=admin_count)
    except Exception as e:
        return jsonify(success=False, message=str(e))

@app.route('/appointments')
def appointments():
    return render_template('appointments.html')

@app.route('/api/appointments', methods=['GET'])
def get_appointments():
    appointments = list(appointments_collection.find())
    appointments_json = json.loads(json_util.dumps(appointments))
    return jsonify(appointments_json)

if __name__ == '__main__':
    app.run(debug=True, port = 5001)
